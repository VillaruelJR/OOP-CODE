﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Villaruel_Simple_Inheritance
{
    internal class Student
    {
        // Properties for the student's name and program
        public string Name { get; set; }
        public string Program { get; set; }

        // Method to display the student's information
        public void DisplayInfo()
        {
            Console.WriteLine("Name: " + Name); // Displaying the name of the student
            Console.WriteLine("Program: " + Program); // Displaying the program of the student
        }
    }

    class RegularStudent : Student // Derived class representing a regular student, inheriting from Student
    {
        public int Section { get; set; } // Property for the regular student's section

        public void SectionEnrolled() // Method to display the section of the regular student
        {
            Console.WriteLine("Section of Student: " + Section); // Displaying the section
        }
    }

    class IrregularStudent : Student // Derived class representing an irregular student, inheriting from Student
    
    {
        public int UnitEnrolled { get; set; } // Property for the number of units the irregular student is enrolled in

        public void EnrolledSemUnits() // Method to display the units the irregular student is enrolled in

        {
            Console.WriteLine("Student Units Enrolled: " + UnitEnrolled); // Displaying the units enrolled
        }
    }
}
