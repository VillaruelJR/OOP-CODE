﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Villaruel_Simple_Inheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //JOHN ROBERT C. VILLARUEL
            //BSIT-301
            //TITLE: Simple Inheritance

            RegularStudent regularStudent = new RegularStudent // Creating an instance of RegularStudent and initializing its properties
            {
                Name = "JOHN ROBERT VILLARUEL", // Setting the student's name
                Program = "BSIT", // Setting the student's program
                Section = 301  // Setting the student's section
            };
            regularStudent.DisplayInfo(); // Displaying the regular student's information
            regularStudent.SectionEnrolled(); // Displaying the section of the regular student
            Console.WriteLine(); // Adding a new line for better readability

            IrregularStudent irregularStudent = new IrregularStudent
            {
                Name = "CHRISTIAN ROLUNA",  // Setting the student's name
                Program = "BSN", // Setting the student's program
                UnitEnrolled = 23 // Setting the number of units the student is enrolled in
            };
            irregularStudent.DisplayInfo(); // Displaying the irregular student's information
            irregularStudent.EnrolledSemUnits(); // Displaying the units enrolled by the irregular student

            Console.ReadKey();
        }
    }
}
