﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace Villaruel_Inheritance_Input_User
{
    internal class Student
    {
        public string name;
        public string program;

        public Student( string bName, string bProgram)
        {
            name = bName;
            program = bProgram;
        }

        public void DisplayInfo()
        {
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Program: " + program);
        }
    }

    class Regularstudent : Student
    {
        public string section;

        public Regularstudent(string bName, string bProgram, string bSection): base(bName, bProgram)
        {
            section = bSection;
        }

        public void SectionEnrolled()
        {
            DisplayInfo();
            Console.WriteLine("Section of student: "+ section);
        }
    }

    class Irregularstudent : Student
    {
        public string unitEnrolled;

        public Irregularstudent (string bName, string bProgram, string bUnitEnrolled) : base(bName, bProgram)
        {
            
            unitEnrolled = bUnitEnrolled;
        }

        public void EnrolledSemUnit()
        {
            DisplayInfo();
            Console.WriteLine("Student Unit Enrolled: " + unitEnrolled);
        }
    }
}
