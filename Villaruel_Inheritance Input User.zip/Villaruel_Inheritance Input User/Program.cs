﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Villaruel_Inheritance_Input_User
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //JOHN ROBERT C VILLARUEL
            //BSIT-301
            //TITLE: Inheritance with User Input


            // Presenting options to the user
            Console.WriteLine("(1) SPORT SHOE ");
            Console.WriteLine("(2) SCHOOL SHOE ");
            Console.WriteLine();
            string choices = Console.ReadLine(); // Reading user input for shoe type choice
            Console.Clear();


            if (choices == "1") // Checking the user's choice for Sport Shoe
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine("SPORT SHOE");
                Console.ResetColor();
                Console.Write("Input Shoe Brand Name: "); // Gathering Sport Shoe details from user
                string bBrandName = Console.ReadLine();
                Console.Write("Input Shoe Price: ");
                string bPrice = Console.ReadLine();
                Console.Write("Input Shoe Color: ");
                string bColor = Console.ReadLine();
                Console.Write("Input Shoe Type: ");
                string bType = Console.ReadLine();

                Console.WriteLine();
                SportShoe sportShoe = new SportShoe(bBrandName, bPrice, bColor, bType); // Creating an instance of SportShoe with user input
                sportShoe.DisplaySportShoe(); // Displaying the details of the Sport Shoe
            }
            else if (choices == "2") // Checking the user's choice for School Shoe
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine("SCHOOL SHOE");
                Console.ResetColor();
                Console.Write("Input Shoe Brand Name: "); // Gathering School Shoe details from user
                string cBrandName = Console.ReadLine();
                Console.Write("Input Shoe Price: ");
                string cPrice = Console.ReadLine();
                Console.Write("Input Shoe Size: ");
                string cSize = Console.ReadLine();
                Console.Write("Input shoe Quantity: ");
                string cQuantity = Console.ReadLine();

                Console.WriteLine();
                SchoolShoe schoolShoe = new SchoolShoe(cBrandName, cPrice, cSize, cQuantity); // Creating an instance of SchoolShoe with user input
                schoolShoe.DisplaySchoolShoe(); // Displaying the details of the School Shoe
            }
            else
            {
                Console.WriteLine("Invalid choice. Please run the program again and select either 1 or 2."); // Handling invalid choices
            }

            Console.ReadKey();
        }
    }
}
