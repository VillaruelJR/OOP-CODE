﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Villaruel_Inheritance_Input_User
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("(1) SPORT SHOE ");
            Console.WriteLine("(2) SCHOOL SHOE ");
            Console.WriteLine();
            string choices = Console.ReadLine();
            Console.Clear();


            if (choices == "1")
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine("SPORT SHOE");
                Console.ResetColor();
                Console.Write("Input Shoe Brand Name: ");
                string bBrandName = Console.ReadLine();
                Console.Write("Input Shoe Price: ");
                string bPrice = Console.ReadLine();
                Console.Write("Input Shoe Color: ");
                string bColor = Console.ReadLine();
                Console.Write("Input Shoe Type: ");
                string bType = Console.ReadLine();

                Console.WriteLine();
                SportShoe sportShoe = new SportShoe(bBrandName, bPrice, bColor, bType);
                sportShoe.DisplaySportShoe();
            }
            else if (choices == "2")
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine("SCHOOL SHOE");
                Console.ResetColor();
                Console.Write("Input Shoe Brand Name: ");
                string cBrandName = Console.ReadLine();
                Console.Write("Input Shoe Price: ");
                string cPrice = Console.ReadLine();
                Console.Write("Input Shoe Size: ");
                string cSize = Console.ReadLine();
                Console.Write("Input shoe Quantity: ");
                string cQuantity = Console.ReadLine();

                Console.WriteLine();
                SchoolShoe schoolShoe = new SchoolShoe(cBrandName, cPrice, cSize, cQuantity);
                schoolShoe.DisplaySchoolShoe();
            }
            else
            {
                Console.WriteLine("Invalid choice. Please run the program again and select either 1 or 2.");
            }

            Console.ReadKey();
        }
    }
}
