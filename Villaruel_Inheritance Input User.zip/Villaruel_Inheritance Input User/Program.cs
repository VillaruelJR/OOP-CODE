﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Villaruel_Inheritance_Input_User
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("REGULAR STUDENT");
            Console.ResetColor();
            Console.Write("input student name: ");
            string bName = Console.ReadLine();
            Console.Write("input student program: ");
            string bProgram = Console.ReadLine();
            Console.Write("input student section: ");
            string bSection = Console.ReadLine();
                    
            
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("IRREGULAR STUDENT");
            Console.ResetColor();
            Console.Write("input student name: ");
            string cName = Console.ReadLine();
            Console.Write("input student program: ");
            string cProgram = Console.ReadLine();
            Console.Write("input student unit enrolled: ");
            string cUnitEnrolled = Console.ReadLine();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("REGULAR STUDENT");
            Console.ResetColor();
            Regularstudent regularstudent = new Regularstudent(bName, bProgram, bSection);
            regularstudent.SectionEnrolled();
            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("IRREGULAR STUDENT");
            Console.ResetColor();
            Irregularstudent irregularstudent = new Irregularstudent(cName, cProgram, cUnitEnrolled);
            irregularstudent.EnrolledSemUnit();
            Console.ReadKey();
        }
    }
}
