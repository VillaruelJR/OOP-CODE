﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace Villaruel_Inheritance_Input_User
{
    internal class Shoe
    {
        public string brandName; // Brand name of the shoe
        public string price; // Price of the shoe

        public Shoe( string bBrandName, string bPrice) // Constructor to initialize brand name and price
        {
            brandName = bBrandName;
            price = bPrice;
        }

        public void DisplayBasicInfo() // Method to display basic shoe information
        {
            Console.WriteLine("Brand Name: " + brandName);
            Console.WriteLine("Price: " + price);
        }
    }

    class SportShoe : Shoe // SportShoe class inherits from Shoe and adds specific properties
    {
        public string color; // Color of the sport shoe
        public string type; // Type of the sport shoe

        public SportShoe(string bBrandName, string bPrice, string bColor, string bType): base(bBrandName, bPrice) // Constructor to initialize sport shoe properties
        {
            color = bColor;
            type = bType;
        }

        public void DisplaySportShoe() // Method to display sport shoe details
        {
            DisplayBasicInfo(); // Displaying basic shoe info
            Console.WriteLine("SportShoe Color: "+ color);
            Console.WriteLine("SportShoe Type: " + type);
        }
    }

    class SchoolShoe : Shoe // SchoolShoe class inherits from Shoe and adds specific properties
    {
        public string size; // Size of the school shoe
        public string quantity; // Quantity of the school shoes

        public SchoolShoe (string bBrandName, string bPrice, string bSize, string bQuantity) : base(bBrandName, bPrice) // Constructor to initialize school shoe properties
        {
            quantity = bQuantity;
            size = bSize;
        }

        public void DisplaySchoolShoe() // Method to display school shoe details
        {
            DisplayBasicInfo(); // Displaying basic shoe info
            Console.WriteLine("School Shoe Size: " + size);
            Console.WriteLine("School Shoe Quantity: " + quantity);
        }
    }
}
