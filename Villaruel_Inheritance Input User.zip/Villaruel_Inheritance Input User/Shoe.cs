﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace Villaruel_Inheritance_Input_User
{
    internal class Shoe
    {
        public string brandName;
        public string price;

        public Shoe( string bBrandName, string bPrice)
        {
            brandName = bBrandName;
            price = bPrice;
        }

        public void DisplayBasicInfo()
        {
            Console.WriteLine("Brande Name: " + brandName);
            Console.WriteLine("Price: " + price);
        }
    }

    class SportShoe : Shoe
    {
        public string color;
        public string type;

        public SportShoe(string bBrandName, string bPrice, string bColor, string bType): base(bBrandName, bPrice)
        {
            color = bColor;
            type = bType;
        }

        public void DisplaySportShoe()
        {
            DisplayBasicInfo();
            Console.WriteLine("SportShoe Color: "+ color);
            Console.WriteLine("SportShoe Type: " + type);
        }
    }

    class SchoolShoe : Shoe
    {
        public string size;
        public string quantity;

        public SchoolShoe (string bBrandName, string bPrice, string bSize, string bQuantity) : base(bBrandName, bPrice)
        {
            quantity = bQuantity;
            size = bSize;
        }

        public void DisplaySchoolShoe()
        {
            DisplayBasicInfo();
            Console.WriteLine("School Shoe Size: " + size);
            Console.WriteLine("School Shoe Quantity: " + quantity);
        }
    }
}
